IELTS Writing Deep Explore Result Portal 2026
================================================

Files:
- index.html: the complete static website.

CURRENT RECORDS
- April Mapal: assignment 80/100; final exam 47/100; SUCCESSFULLY PASS
- Md Salik Raza: assignment 86/100; final exam 52.5/100; SUCCESSFULLY PASS
- Deep (Ayaan Malik): assignment 85/100; final exam 83.5/100; SUCCESSFULLY PASS
- Nova: no assignment result provided; final exam 70/100; FAIL — NO ASSIGNMENT

The pass/fail labels follow the lecturer's instruction that April, Salik and Deep pass, while students without an assignment fail. Review the scores and statuses before public release.

PUBLISH WITH GITHUB PAGES
1. Create/sign in to https://github.com/
2. Create a public repository named ielts-result-portal.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish and copy the live URL shown on the Pages settings screen.

IMPORTANT PRIVACY NOTE
This is a static public website. Names, marks, status and feedback are included in the source code and can be inspected by anyone. First-name lookup is not a security control. Publish only if you have permission to share student results; for confidential records, use authenticated access or unique private result codes.

AI percentages are reproduced as reported on the supplied assignment result cards; they are not independently verified.
